package gestion;

public class Camion extends Vehicule{
    private double capaciteDeChargement;
    private int nombreEssieux;
    public Camion(String immatriculation, String marque, String modele, int annee, int kilometrage, double capaciteDeChargement, int nombreEssieux) {
        super(immatriculation, marque, modele, annee, kilometrage);
        this.capaciteDeChargement = capaciteDeChargement;
        this.nombreEssieux = nombreEssieux;
    }

    @Override
    public double calculerPrixLocation() {
        return 100000;
    }
}
