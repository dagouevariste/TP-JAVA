package gestion;
import java.util.ArrayList;
class Client {
    public String nom;
    public String prenom;
    public String numeroPermis;
    public Double numeroTelephone;
    public ArrayList<Vehicule> locationsEnCours;

    public Client(String nom, String prenom, String numeroPermis, double numeroTelephone) {
        this.nom = nom;
        this.prenom = prenom;
        this.numeroPermis = numeroPermis;
        this.numeroTelephone = numeroTelephone;
        this.locationsEnCours = new ArrayList<>();
    }

       public void stockerLocationEffectuer(Vehicule vehicule) throws ClientNonAutoriseException, VehiculeIndisponibleException {
        if (vehicule instanceof Camion && !numeroPermis.startsWith("C")) { // Exemple : Vérification basique d'un permis de camion
            throw new ClientNonAutoriseException("Client non autorisé à louer un camion sans permis adéquat.");
        }
        locationsEnCours.add(vehicule);
        vehicule.louer(); // Loue le véhicule après avoir ajouté à la liste
    }

    public void retirerLocation(Vehicule vehicule) {
        locationsEnCours.remove(vehicule);
    }


}