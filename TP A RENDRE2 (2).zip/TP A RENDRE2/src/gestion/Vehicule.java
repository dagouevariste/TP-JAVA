package gestion;

public abstract class Vehicule implements Louable {
    public String immatriculation;
    public String marque;
    public String modele;
    public int annee ;
    public int kilometrage ;
    public boolean statut ;

    public Vehicule(String immatriculation, String marque, String modele, int annee, int kilometrage) {
        this.immatriculation = immatriculation;
        this.marque = marque;
        this.modele = modele;
        this.annee = annee;
        this.kilometrage = kilometrage;
        this.statut = true ;
    }
    public abstract double calculerPrixLocation();
    public void louer() throws VehiculeIndisponibleException {
        if (!statut) {
            throw new VehiculeIndisponibleException("le vehicule de marque "+marque+"et d'immaticulation : "+ immatriculation+ " est loué");
        }
        this.statut = false; // changer le statut à loué
        System.out.println( "le vehicule de marque "+marque+"et d'immaticulation : "+ immatriculation+ " est disponible" );
    }
    public void retourner (){
        System.out.println("la voiture de marque : "+marque+" de modele : "+modele+" d'immaticulation : "+immatriculation+" est : "+(statut ?"disponible" : "louer"));
    }
}
