package gestion;

class Voiture extends Vehicule{
    private int nombreDePlaces;
    private String typeDeCarburant;

    public Voiture(String immatriculation, String marque, String modele, int annee, int kilometrage, int nombreDePlaces, String typeDeCarburant) {
        super(immatriculation, marque, modele, annee, kilometrage);
        this.nombreDePlaces = nombreDePlaces;
        this.typeDeCarburant = typeDeCarburant;
    }

    @Override
    public double calculerPrixLocation() {
        return 50000 ;
    }


}
