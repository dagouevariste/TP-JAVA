package gestion;
import java.util.ArrayList;
import java.util.Scanner;


public class ParcAutomobile {
    private static ArrayList<Client> clients = new ArrayList<>();
    private static ArrayList<Vehicule> vehicules = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean quitter = true ;


        while ( quitter) {
            System.out.println("\nMenu:");
            System.out.println("1. Ajouter un véhicule");
            System.out.println("2. Ajouter un client");
            System.out.println("3. Louer un véhicule");
            System.out.println("4. Retourner un véhicule");
            System.out.println("5. Liste des véhicules ");
            System.out.println("6. Quitter");
            System.out.println("Choisissez une option: ");
            int choix = scanner.nextInt();

            switch (choix) {
                case 1:
                    ajouterUnVehicule();
                    break;
                case 2:
                    AjouterUnClient();
                    break;
                case 3:
                    LouerUnVehicule();
                    break;
                case 4:
                    retournerUnVehicule();
                    break;
                case 5:
                    listerVehicules();
                    break;
                case 6:
                    System.out.println("Au revoir!");
                    //scanner.close();
                    quitter = false;
                    break;
                default:
                    System.out.println("Choix invalide, veuillez réessayer.");

                }
            }

        }
    static Scanner sc =new Scanner(System.in);
    static void ajouterUnVehicule (){
        System.out.print("Selectionner le type de véhicule 1- pour Voiture et 2-pour Camion : ");
        String type = sc.nextLine();

        System.out.print("Immatriculation: ");
        String immatriculation = sc.nextLine();

        System.out.print("Marque: ");
        String marque = sc.nextLine();

        System.out.print("Modèle: ");
        String modele = sc.nextLine();

        System.out.print("Année: ");
        int annee = sc.nextInt();

        System.out.print("Kilométrage: ");
        int kilometrage = sc.nextInt();
        if (type.equalsIgnoreCase("1")) {
            System.out.print("Nombre de places: ");
            int nombreDePlaces = sc.nextInt();
            sc.nextLine();

            System.out.print("Selectionner le type de carburant (essence/ diesel/électrique) : ");
            String typeDeCarburant = sc.nextLine();

            Voiture voiture = new Voiture(immatriculation, marque, modele, annee, kilometrage, nombreDePlaces, typeDeCarburant);
            vehicules.add(voiture);
            System.out.println("Véhicule ajouté : " + immatriculation);
        } else if (type.equalsIgnoreCase("2")) {
            System.out.print("Capacité de chargement (en tonnes): ");
            double capaciteDeChargement = sc.nextDouble();

            System.out.print("Nombre d'essieux: ");
            int nombreEssieux = sc.nextInt();
            Camion camion = new Camion(immatriculation, marque, modele, annee, kilometrage, capaciteDeChargement, nombreEssieux);
            vehicules.add(camion);
            System.out.println("Véhicule ajouté : " + immatriculation);
        } else {
            System.out.println("Type de véhicule non reconnu.");
        }

    }
    private static void AjouterUnClient(){
        System.out.println("Entrez le nom : ");
        String nom = sc.nextLine();
        System.out.println("Prénom: ");
        String prenom = sc.nextLine();
    
        System.out.println("Numéro de permis: ");
        String numeroPermis = sc.nextLine();
    
        System.out.println("Numéro de téléphone: ");
    double numeroTelephone = sc.nextDouble();
                    sc.nextLine();

    Client client = new Client(nom, prenom, numeroPermis, numeroTelephone);
                    clients.add(client);
                    System.out.println("Client ajouté : " + nom + " " + prenom);
    }
    private static void LouerUnVehicule() {
        System.out.println("Liste des véhicules disponibles :");
        for (int i = 0; i < vehicules.size(); i++) {
            if (vehicules.get(i).statut) { // Vérifie si le véhicule est disponible
                System.out.println(i + 1 + ". " + vehicules.get(i).immatriculation + " - " + vehicules.get(i).marque + " " + vehicules.get(i).modele);
            }
        }

        System.out.print("Choisissez le numéro du véhicule à louer : ");
        int vehiculeChoisi = sc.nextInt() - 1;
        sc.nextLine();

        if (vehiculeChoisi < 0 || vehiculeChoisi >= vehicules.size() || !vehicules.get(vehiculeChoisi).statut) {
            System.out.println("Véhicule non valide ou déjà loué.");
            return;
        }

        System.out.println("Liste des clients :");
        for (int i = 0; i < clients.size(); i++) {
            System.out.println(i + 1 + ". " + clients.get(i).nom + " " + clients.get(i).prenom);
        }

        System.out.print("Choisissez le numéro du client : ");
        int clientChoisi = sc.nextInt() - 1;
        sc.nextLine();

        if (clientChoisi < 0 || clientChoisi >= clients.size()) {
            System.out.println("Client non valide.");
            return;
        }

        Client client = clients.get(clientChoisi);
        Vehicule vehicule = vehicules.get(vehiculeChoisi);


        if (vehicule instanceof Camion && !client.numeroPermis.startsWith("C")) { // Supposons que le permis camion commence par 'C'
            System.out.println("Le client " + client.nom + " " + client.prenom + " n'est pas autorisé à louer un camion.");
            return;
        }

        try {
            vehicule.louer();
            client.stockerLocationEffectuer(vehicule);
        } catch (VehiculeIndisponibleException e) {
            System.out.println(e.getMessage());
        } catch (ClientNonAutoriseException e) {
            throw new RuntimeException(e);
        }
    }
    private static void retournerUnVehicule() {
        System.out.println("Liste des clients :");
        for (int i = 0; i < clients.size(); i++) {
            System.out.println(i + 1 + ". " + clients.get(i).nom + " " + clients.get(i).prenom);
        }

        System.out.print("Choisissez le numéro du client : ");
        int clientChoisi = sc.nextInt() - 1;
        sc.nextLine();

        if (clientChoisi < 0 || clientChoisi >= clients.size()) {
            System.out.println("Client non valide.");

        }

        Client client = clients.get(clientChoisi);
        System.out.println("Véhicules loués par " + client.nom + " " + client.prenom + ":");
        for (int i = 0; i < client.locationsEnCours.size(); i++) {
            System.out.println(i + 1 + ". " + client.locationsEnCours.get(i).immatriculation + " - " + client.locationsEnCours.get(i).marque + " " + client.locationsEnCours.get(i).modele);
        }

        System.out.print("Choisissez le numéro du véhicule à retourner : ");
        int vehiculeChoisi = sc.nextInt() - 1;
        sc.nextLine();

        if (vehiculeChoisi < 0 || vehiculeChoisi >= client.locationsEnCours.size()) {
            System.out.println("Véhicule non valide.");

        }

        Vehicule vehicule = client.locationsEnCours.get(vehiculeChoisi);
        vehicule.retourner();
        client.retirerLocation(vehicule);
        System.out.println("Véhicule retourné : " + vehicule.immatriculation);
    }
    private static void listerVehicules() {
        System.out.println("Liste des véhicules :");
        for (int i = 0; i < vehicules.size(); i++) {
            System.out.println(i + 1 + ".Le véhicule immatriculé : " + vehicules.get(i).immatriculation + " , de marque : " + vehicules.get(i).marque + ", de modele : " + vehicules.get(i).modele + ", est : " + (vehicules.get(i).statut ? "Disponible" : "Loué"));
        }
    }
}